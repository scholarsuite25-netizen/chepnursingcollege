# Updated 6-Station Autonomous CAOSCE Architecture & Implementation Plan
**Document Version:** 2.0.0  
**Target Module:** `src/app/exams/page.tsx` & `src/data/caosceExams.ts`  
**Standard:** Nursing and Midwifery Council of Nigeria (NMCN), NCLEX, WHO & International Board Accreditation  
**Execution Model:** 100% Fully Online & Autonomous (Zero Human Intervention)  
**Status:** Awaiting User Approval Prior to Implementation

---

## 1. Executive Summary of Updates

Following your review and specific directions, this plan confirms four key operational updates:

1. **MCQ Timing Confirmed**:
   - **10 Minutes allocated for the 10 MCQs at each station** (60 seconds per question).
   - This creates balanced symmetry with the 10-minute practical:
     - 10 minutes Practical + 10 minutes MCQs = **20 minutes per station**.
     - Across all 6 stations: **120 minutes (2.0 hours) total examination circuit**.
2. **100% Online & Fully Autonomous (Zero Human Intervention)**:
   - Eliminates external human examiner dependency.
   - The web platform itself acts as the automated proctor, timer, patient simulator, invigilator, and grading engine.
   - The student navigates through the exam autonomously following on-screen instructions, executing clinical procedure steps, and submitting decisions.
   - Automated audio/visual station bells sound at 2 minutes remaining and at 0:00 station changeover.
   - Auto-advance on expiry ensures strict timing enforcement.
3. **Deletion of Legacy OSCE Version**:
   - The earlier manual 102-station browser tab with examiner checkboxes in `src/app/exams/page.tsx` will be completely removed.
   - The new 6-Station Autonomous CAOSCE circuit will replace it cleanly as the official OSCE platform.
4. **Global Reusable Specification Prompt**:
   - Generated and made available in both Markdown and plain-text format for direct download and reuse across any other web application project:
     - [GLOBAL_CAOSCE_SYSTEM_SPECIFICATION_PROMPT.md](file:///c:/Users/Registrar/Music/stitch_nursing_college_next.js_migration/GLOBAL_CAOSCE_SYSTEM_SPECIFICATION_PROMPT.md)
     - [GLOBAL_CAOSCE_SYSTEM_SPECIFICATION_PROMPT.txt](file:///c:/Users/Registrar/Music/stitch_nursing_college_next.js_migration/GLOBAL_CAOSCE_SYSTEM_SPECIFICATION_PROMPT.txt)

---

## 2. Timetable & Sequential Lockstep Progression

$$\begin{aligned}
\mathbf{\text{Station 1: Med-Surg Nursing}} &\quad \text{Practical (10 min)} \longrightarrow \text{MCQs 1--10 (10 min)} \longrightarrow \text{30s Bell Transition} \\
\mathbf{\text{Station 2: Maternal Nursing}} &\quad \text{Practical (10 min)} \longrightarrow \text{MCQs 1--10 (10 min)} \longrightarrow \text{30s Bell Transition} \\
\mathbf{\text{Station 3: Pediatric Nursing}} &\quad \text{Practical (10 min)} \longrightarrow \text{MCQs 1--10 (10 min)} \longrightarrow \text{30s Bell Transition} \\
\mathbf{\text{Station 4: Mental Health}} &\quad \text{Practical (10 min)} \longrightarrow \text{MCQs 1--10 (10 min)} \longrightarrow \text{30s Bell Transition} \\
\mathbf{\text{Station 5: Public Health}} &\quad \text{Practical (10 min)} \longrightarrow \text{MCQs 1--10 (10 min)} \longrightarrow \text{30s Bell Transition} \\
\mathbf{\text{Station 6: Trauma & Emergency}} &\quad \text{Practical (10 min)} \longrightarrow \text{MCQs 1--10 (10 min)} \longrightarrow \text{Final Board Scorecard}
\end{aligned}$$

- **Total Stations:** 6
- **Total Practical Time:** 60 minutes
- **Total MCQ Time:** 60 minutes (60 questions total)
- **Total Circuit Duration:** 120 minutes (2.0 Hours)

---

## 3. Autonomous Execution & Zero Human Intervention Flow

```mermaid
graph TD
    A["Candidate Enters Lobby<br/>(Enters Name & Index No; Reads Instructions)"] --> B["Start CAOSCE Circuit"]
    B --> S1P["Station 1: Med-Surg Practical<br/>(10-Min Autonomous Timer)"]
    S1P -->|10 mins expire or click submit| S1M["Station 1: 10 MCQs<br/>(10-Min Autonomous Timer)"]
    S1M -->|10 mins expire or click submit| T1["30s Station Bell Transition"]
    T1 --> S2P["Station 2: Maternal Practical (10m)"]
    S2P --> S2M["Station 2: 10 MCQs (10m)"]
    S2M --> T2["30s Station Bell Transition"]
    T2 --> S3P["Station 3: Pediatric Practical (10m)"]
    S3P --> S3M["Station 3: 10 MCQs (10m)"]
    S3M --> T3["30s Station Bell Transition"]
    T3 --> S4P["Station 4: Psychiatric Practical (10m)"]
    S4P --> S4M["Station 4: 10 MCQs (10m)"]
    S4M --> T4["30s Station Bell Transition"]
    T4 --> S5P["Station 5: Community Health Practical (10m)"]
    S5P --> S5M["Station 5: 10 MCQs (10m)"]
    S5M --> T5["30s Station Bell Transition"]
    T5 --> S6P["Station 6: Emergency Trauma Practical (10m)"]
    S6P --> S6M["Station 6: 10 MCQs (10m)"]
    S6M --> Score["Automated Composite Grading & Official Council Result Slip"]
```

### Self-Proctoring Interaction Rules:
1. **Interactive Clinical Step Execution:**
   - Candidate reviews the patient dossier, vital signs, and equipment trolley.
   - Candidate clicks to execute each action in priority sequence (e.g. confirming identity, donning sterile PPE, applying Levine technique, checking for second twin before oxytocin).
   - The system tracks execution and scores the candidate instantly.
2. **Critical Patient Safety Fail Points:**
   - Certain steps are marked `criticalFailStep: true`.
   - If a student skips or incorrectly performs a critical safety step, the engine logs a **"Critical Patient Safety Violation"** with a detailed explanation on their final transcript.
3. **Automated Bell Timers:**
   - Practical Bell: 10:00 countdown. At 02:00, visual amber pulse alert. At 00:00, digital bell sounds and interface locks.
   - MCQ Bell: 10:00 countdown. At 00:00, responses are captured and the station advances automatically.
4. **Permanent State Locking:**
   - No backward navigation to modify past stations.
   - No jumping ahead to preview future stations.

---

## 4. Deletion of the Legacy OSCE Version

In `src/app/exams/page.tsx`:
- The previous Tab 3 (`activeTab === "osce"` with 102 individual stations) and its associated state (`selectedStationId`, `osceTimeRemaining`, `filteredOSCE`, `totalOscePointsEarned`, etc.) will be completely deleted.
- The new tab layout will be:
  - `📝 CBT MCQ Testing` (100 Qs / 50 Qs / 25 Qs mock sessions)
  - `📄 Clinical Essay Bank` (52 multi-part clinical case studies)
  - `🩺 6-Station CAOSCE Circuit` (100% Online & Autonomous)
- All legacy manual OSCE UI elements, checkboxes, and sidebars will be purged, ensuring a clean, modern, and focused codebase.

---

## 5. Verification Plan

### Automated Tests
- Create `tests/caosce_autonomous_circuit.test.mjs`:
  - Verify that exactly 6 stations are configured.
  - Verify that each station has `durationMinutes: 10`.
  - Verify that each station has exactly 10 linked MCQs (60 questions total).
  - Verify that each MCQ section is allocated 10 minutes (600 seconds).
  - Verify scoring calculation: $50\%$ practical $+ 50\%$ MCQ composite score.
  - Verify that critical safety failure flags are recorded accurately.
- Run `npm test` to verify all security, RLS, and application tests pass.
- Run `npx tsc --noEmit` and `npm run build` to confirm zero compilation errors.

---

## 6. Request for Permission

> [!IMPORTANT]
> **Awaiting Your Approval**:
> I have confirmed the 10-minute MCQ timing, structured the 100% online autonomous workflow, outlined the complete removal of the legacy OSCE tab, and generated the downloadable global prompt files for you.
> 
> **Do you approve this plan to begin implementation?**
